/**
* @author jose garcía
* @date= 10-10-2019
* @description functions for index.html
* @version 1.0
 */
var capsOn=false;
var capsLockOn=false;

window.onload = function(){
	updateClock();
	nav();
	setInterval(updateClock, 1000);
}
/**
*@description shows the nav info in html div.
*/
function nav(){

    var result="";

		result+="<p><b>CodeName:</b> "+navigator.appCodeName +"</p>";
		result+="<p><b>AppName:</b> "+navigator.appName +"</p>";
		result+="<p><b>AppVersion:</b> "+navigator.appVersion +"</p>";
		result+="<p><b>CookieEnabled:</b> "+navigator.cookieEnabled +"</p>";
		result+="<p><b>UserAgent:</b> "+navigator.userAgent +"</p>";

		document.getElementById("nav").innerHTML = result;
}
/**
*@description define the actions of the keys
*/
function key(valor){

	var typeOfKey=valor.innerText;
	var letter = document.getElementById("write");


	switch (typeOfKey) {

		case "SPACE":

		  letter.value+=" ";
		  break;
		case "DEL":

			letter.value=letter.value.substring(0,letter.value.length-1);
		  break;
		case "ENTER":

			letter.value+="\n";
		  break;
		case "CAPS":

		  toogleCaps();
		  break;
		case "CAPSLOCK":

		  toogleCapsLock();
		  break;
		default:

			letter.value+=typeOfKey;

		  if(capsOn){

			toogleCaps();
		  }
	  }

}

function toogleCaps(){

	capsOn=!capsOn;
	if(capsOn){

	  document.getElementById("btnCAPS").classList.add("mayusON");
	}else{

	  document.getElementById("btnCAPS").classList.remove("mayusON");
	}
	keyControl();
}

function toogleCapsLock(){

	capsLockOn=!capsLockOn;
	if(capsLockOn){

	  document.getElementById("btnCAPSLOCK").classList.add("mayusON");
	}else{

	  document.getElementById("btnCAPSLOCK").classList.remove("mayusON");
	}
	keyControl();
}
/**
 * @description sets the control of button type by id
 */
function keyControl(){

	var setMayus=capsLockOn;
	if(capsOn){

	  setMayus=!setMayus;
	}

	var buttons=document.getElementsByTagName("button");

	for (var i = buttons.length-1; i >= 0; i--) {

	  var buttonId=buttons[i].id;

	  if(buttonId.length>3 && buttonId.substring(0,3)=="btn"){

		switch(buttonId){

		  case "btnCAPS":
		  case "btnCAPSLOCK":
		  case "btnSPACE":
		  case "btnDEL":
		  case "btnENTER":

			break;
		  default:
			
			if(setMayus){

			  //makes uppercase
			  document.getElementById(buttonId).innerText=document.getElementById(buttonId).innerText.toUpperCase();
			}else{

			  //makes lowercase
			  document.getElementById(buttonId).innerText=document.getElementById(buttonId).innerText.toLowerCase();
			}

		}
	  }
	}
}
/**
* @description function to update clock info.
*/
function updateClock() {
	var today = new Date();
	var day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
	var month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	var ordinal;
	switch (today.getDate()) {
	  case 1:
		ordinal = "st"
		break;
	  case 2:
		ordinal = "nd"
		break;
	  case 3:
		ordinal = "rd"
		break;
	  default:
		ordinal = "th"
	}
	document.getElementById("clock").innerHTML =  (day[today.getDay()] + " " + ('0' + (today.getDate())).slice(-2) + ordinal + " " + month[today.getMonth()] + " " + today.getFullYear() + ", " + ('0' + (today.getHours())).slice(-2) + ":" + ('0' + (today.getMinutes())).slice(-2) + ":" + ('0' + (today.getSeconds())).slice(-2) );
  }
